import firebase from 'firebase/app';
import 'firebase/auth';
import 'firebase/database';

const envs = process.env;

const prodConfig = {
  apiKey: envs.REACT_APP_FIREBASE_API_KEY,
  authDomain: envs.REACT_APP_FIREBASE_AUTH_DOMAIN,
  databaseURL: envs.REACT_APP_FIREBASE_DATABASE_URL,
  projectId: envs.REACT_APP_FIREBASE_PROJECT_ID,
  storageBucket: envs.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: envs.REACT_APP_FIREBASE_MESSAGING_SENDER_ID
};

const devConfig = {
  apiKey: envs.REACT_APP_FIREBASE_API_KEY,
  authDomain: envs.REACT_APP_FIREBASE_AUTH_DOMAIN,
  databaseURL: envs.REACT_APP_FIREBASE_DATABASE_URL,
  projectId: envs.REACT_APP_FIREBASE_PROJECT_ID,
  storageBucket: envs.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: envs.REACT_APP_FIREBASE_MESSAGING_SENDER_ID
};

const config = process.env.NODE_ENV === 'production'
  ? prodConfig
  : devConfig;

if (!firebase.apps.length) {
  firebase.initializeApp(config);
}

const db = firebase.database();
const auth = firebase.auth();

export {
  db,
  auth,
};
